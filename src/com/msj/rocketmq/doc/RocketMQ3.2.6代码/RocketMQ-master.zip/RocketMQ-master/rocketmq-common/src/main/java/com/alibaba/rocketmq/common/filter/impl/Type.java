package com.alibaba.rocketmq.common.filter.impl;

/**
 * @auther lansheng.zj@taobao.com
 */
public enum Type {
    NULL,
    OPERAND,
    OPERATOR,
    PARENTHESIS,
    SEPAERATOR;
}
