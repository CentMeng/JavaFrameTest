package com.alibaba.rocketmq.common.filter.impl;

/**
 * @auther lansheng.zj@taobao.com
 */
public class Operand extends Op {

    public Operand(String symbol) {
        super(symbol);
    }

}
