/**
 * $Id: MixTest.java 1831 2013-05-16 01:39:51Z shijia.wxr $
 */
package com.alibaba.rocketmq.remoting;

import org.junit.Test;


/**
 * @author shijia.wxr<vintage.wang@gmail.com>
 */
public class MixTest {
    @Test
    public void test_extFieldsValue() {

    }
}
