package com.alibaba.rocketmq.common.namesrv;

/**
 * @author shijia.wxr<vintage.wang@gmail.com>
 * @since 2013-7-5
 */
public class NamesrvUtil {
    public static final String NAMESPACE_ORDER_TOPIC_CONFIG = "ORDER_TOPIC_CONFIG";
    public static final String NAMESPACE_PROJECT_CONFIG = "PROJECT_CONFIG";
}
